/* K线训练营 · 期货核心：数据解码、保证金交易、存档。
   桌面端与手机端共用（同一响应式页面）。 */
(function (global) {
  'use strict';

  var EPOCH = Date.UTC(2019, 0, 1);
  var DAY = 86400000;
  var STEP = 22;
  var ROUND_KEY = 'klineFutRound';
  var DATE_CACHE = (function () {
    var list = [];
    for (var i = 0; i < 65536; i++) {
      var d = new Date(EPOCH + i * DAY);
      list[i] = d.getUTCFullYear() + '-' +
        String(d.getUTCMonth() + 1).padStart(2, '0') + '-' +
        String(d.getUTCDate()).padStart(2, '0');
    }
    return list;
  })();

  function base64ToBytes(b64) {
    var bin = atob(b64);
    var out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  async function inflate(bytes) {
    var stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate'));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  function decode(bytes, e) {
    var view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    var bars = new Array(e.k);
    var pos = e.o * STEP;
    for (var i = 0; i < e.k; i++, pos += STEP) {
      bars[i] = {
        d: DATE_CACHE[view.getUint16(pos, true)],
        o: view.getInt32(pos + 2, true) / 1000,
        h: view.getInt32(pos + 6, true) / 1000,
        l: view.getInt32(pos + 10, true) / 1000,
        c: view.getInt32(pos + 14, true) / 1000,
        v: view.getInt32(pos + 18, true)
      };
    }
    return bars;
  }

  async function loadData() {
    var idx = global.KLINE_FUT_INDEX || [];
    var pack = global.KLINE_FUT_PACK;
    if (!pack) return [];
    var bytes = await inflate(base64ToBytes(pack));
    return idx.map(function (e) {
      return {
        code: e.c, name: e.n, ex: e.x, mul: e.mul, tick: e.tick, mr: e.mr,
        k: e.k, d0: e.d0, d1: e.d1, lo: e.lo, bars: decode(bytes, e)
      };
    });
  }

  /* ---------------- 账户与交易 ---------------- */
  function updn(r, price) {
    if (!r.dir || !r.lots) return 0;
    return (price - r.avg) * r.sym.mul * r.lots * r.dir;
  }
  function equityOf(r, price) { return r.cash + updn(r, price); }
  function marginOf(r, price) {
    if (!r.dir || !r.lots) return 0;
    return price * r.sym.mul * r.lots * r.sym.mr;
  }
  function availOf(r, price) { return equityOf(r, price) - marginOf(r, price); }
  function riskOf(r, price) {
    var m = marginOf(r, price);
    if (!(m > 0)) return 0;
    var e = equityOf(r, price);
    return e > 0 ? m / e : 99;
  }
  function feeOf(r, price, lots) {
    return price * r.sym.mul * lots * r.feeRate;
  }
  function maxLots(r, price, dir) {
    // 逐手试算，最多 500 手，避免极端价格下的死循环
    var n = 0, e0 = equityOf(r, price);
    for (var i = 1; i <= 500; i++) {
      var add = price * r.sym.mul * i * r.sym.mr;
      if (e0 - marginOf(r, price) < add + interestOf(r, price, i)) break;
      n = i;
    }
    return n;
  }
  function interestOf(r, price, lots) {
    // 期货无利息，保留接口便于扩展
    return 0;
  }

  function openPos(r, dir, price, lots, src) {
    if (!r || r.finished) return { ok: false, error: '本局已结束' };
    lots = Math.floor(lots);
    if (!(lots > 0)) return { ok: false, error: '请输入手数' };
    if (r.dir && r.dir !== dir) return { ok: false, error: '已有反向持仓，请先平仓' };
    var fee = feeOf(r, price, lots);
    var need = price * r.sym.mul * lots * r.sym.mr;
    if (availOf(r, price) < need + fee) {
      return { ok: false, error: '可用资金不足，最多可开 ' + maxLots(r, price, dir) + ' 手' };
    }
    if (r.dir === 0) {
      r.dir = dir;
      r.avg = price;
      r.lots = lots;
      r.entryIdx = r.cur;
    } else {
      r.avg = (r.avg * r.lots + price * lots) / (r.lots + lots);
      r.lots += lots;
    }
    r.cash -= fee;
    r.orders.push({
      i: r.cur, act: 'open', dir: dir, price: price, lots: lots, fee: fee, src: src || '手动'
    });
    return { ok: true, act: 'open', dir: dir, lots: lots, fee: fee };
  }

  function closePos(r, price, lots, src) {
    if (!r || r.finished) return { ok: false, error: '本局已结束' };
    if (!r.dir || !r.lots) return { ok: false, error: '当前没有持仓' };
    lots = lots > 0 ? Math.min(Math.floor(lots), r.lots) : r.lots;
    if (!(lots > 0)) return { ok: false, error: '请输入平仓手数' };
    var pnl = (price - r.avg) * r.sym.mul * lots * r.dir;
    var fee = feeOf(r, price, lots);
    r.cash += pnl - fee;
    r.closed.push({
      i: r.cur, dir: r.dir, lots: lots, pnl: pnl, fee: fee,
      hold: r.cur - (r.entryIdx == null ? r.cur : r.entryIdx), src: src || '手动'
    });
    r.orders.push({
      i: r.cur, act: 'close', dir: r.dir, price: price, lots: lots, fee: fee, pnl: pnl, src: src || '手动'
    });
    r.lots -= lots;
    if (r.lots <= 0) { r.lots = 0; r.dir = 0; r.avg = 0; r.entryIdx = null; }
    return { ok: true, act: 'close', lots: lots, fee: fee, pnl: pnl };
  }

  function checkForced(r, price) {
    if (!r || r.finished || !r.dir || !r.lots) return null;
    var risk = riskOf(r, price);
    if (risk < 1) return null;
    var lots = r.lots;
    closePos(r, price, lots, '强制平仓');
    r.forced = (r.forced || 0) + 1;
    return { risk: risk, lots: lots };
  }

  function newRound(sym, start, len, capital, feeRate) {
    return {
      sym: sym, start: start, len: len, end: start + len - 1, cur: start,
      initial: capital, cash: capital,
      dir: 0, lots: 0, avg: 0, entryIdx: null,
      orders: [], closed: [],
      curve: [{ i: start, eq: capital }], peak: capital, mdd: 0,
      feeRate: feeRate, forced: 0, finished: false
    };
  }

  function saveRound(r) {
    if (!r || r.finished) return;
    try {
      localStorage.setItem(ROUND_KEY, JSON.stringify({
        v: 1, code: r.sym.code,
        start: r.start, cur: r.cur, len: r.len, end: r.end,
        sd: r.sym.bars[r.start].d, cd: r.sym.bars[r.cur].d,
        initial: r.initial, cash: r.cash, dir: r.dir, lots: r.lots, avg: r.avg,
        entryIdx: r.entryIdx, orders: r.orders, closed: r.closed,
        curve: r.curve, peak: r.peak, mdd: r.mdd,
        feeRate: r.feeRate, forced: r.forced || 0
      }));
    } catch (e) { }
  }
  function clearRound() {
    try { localStorage.removeItem(ROUND_KEY); } catch (e) { }
  }
  function loadRound(raw, warmup) {
    var o;
    try { o = JSON.parse(localStorage.getItem(ROUND_KEY) || 'null'); } catch (e) { return null; }
    if (!o || o.v !== 1 || !o.code) return null;
    var sym = null;
    for (var i = 0; i < raw.length; i++) if (raw[i].code === o.code) { sym = raw[i]; break; }
    if (!sym) return null;
    var si = -1, ci = -1;
    for (var j = 0; j < sym.bars.length; j++) {
      if (sym.bars[j].d === o.sd) si = j;
      if (sym.bars[j].d === o.cd) ci = j;
    }
    if (si < 0 || ci < 0) return null;
    if (ci < si || si + o.len - 1 >= sym.bars.length) return null;
    var delta = si - o.start;
    var shift = function (arr) {
      return (arr || []).map(function (x) { x.i += delta; return x; });
    };
    var r = {
      sym: sym, start: si, len: o.len, end: si + o.len - 1, cur: ci,
      initial: o.initial, cash: o.cash, dir: o.dir || 0, lots: o.lots || 0,
      avg: o.avg || 0, entryIdx: o.entryIdx == null ? null : o.entryIdx + delta,
      orders: shift(o.orders), closed: shift(o.closed),
      curve: shift(o.curve), peak: o.peak || o.initial, mdd: o.mdd || 0,
      feeRate: o.feeRate > 0 ? o.feeRate : 0.0001, forced: o.forced || 0,
      finished: false
    };
    if (r.curve.length && r.curve[r.curve.length - 1].i !== r.cur) {
      r.curve.push({ i: r.cur, eq: equityOf(r, sym.bars[r.cur].c) });
    }
    return r;
  }

  global.KC_FUT = {
    loadData: loadData, newRound: newRound,
    equityOf: equityOf, marginOf: marginOf, availOf: availOf, riskOf: riskOf, feeOf: feeOf,
    maxLots: maxLots, openPos: openPos, closePos: closePos, checkForced: checkForced,
    saveRound: saveRound, clearRound: clearRound, loadRound: loadRound, ROUND_KEY: ROUND_KEY
  };
})(typeof window !== 'undefined' ? window : this);
